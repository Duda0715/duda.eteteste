nivelDificuldade = Number(window.prompt("Qual a o nível de dificuladade você gostaria de jogar? Resposta de 1 a 10")) //pedido para o jogador solicitar o nível de dificuldade ele quer.

var xBolinha = 300; //posição da largura da bolinha.
var yBolinha = 200; //posição de altura da bolinha.
var velocidadeX = nivelDificuldade; //velocidade da bolinha em x de acordo com o nível que o jogador solicitou.
var velocidadeY = nivelDificuldade; //velocidade da bolinha em y de acordo com o nível que o jogador solicitou.
var dBolinha = 20; //diametro da bolinha.
var corTabuleiro = "#40E0D0"; //cor do tabuleiro.
var largura = 600; //largura de 600 pixels.
var altura = 400; //altura de 400 pixels.


function setup() {
  createCanvas(largura, altura); //quadrado de largura 600 pixels e altura 400 pixels.
}


function criarTabuleiro(corTabuleiro){
    background(corTabuleiro); //cor do quadrado é preto. Se for cor em hexadecimal temos que colocar dentro de aspas.
}


function criarBolinha(){
  circle(xBolinha, yBolinha, 20); //bolinha que seu centro fica na largura 300 pixels, altura 200 pixels, que no caso vai ficar no meio, pois é a metade da largura e altura total, e 20 é o tamanho da bolinha.
  fill(0, 0, 0);
}


function movimentarBolinha(){
   xBolinha = xBolinha+velocidadeX; //para a posição de largura da bolinha sempre aumentar 1 quando passar por esse comando em loop.
  yBolinha = yBolinha+velocidadeY; //para a posição de altura da bolinha sempre aumentar 1 quando passar por esse comando em loop.
}


function verificarColisao(){
    if((xBolinha >= (600-(dBolinha/2))) || (xBolinha<(dBolinha/2))) {
    velocidadeX = -1 * velocidadeX
  }
    
    if((yBolinha >= (400-(dBolinha/2))) || (yBolinha<(dBolinha/2))) {
    velocidadeY = -1 * velocidadeY
  }
}


function draw() { //função desenhar, é uma função de loop..
  criarTabuleiro(corTabuleiro);//chama a função criarTabuleiro.
  criarBolinha();//chama a função criarBolinha.
  movimentarBolinha();//chama a função movimentarBolinha.
  verificarColisao(); //chama a função verificarColisao.
}
